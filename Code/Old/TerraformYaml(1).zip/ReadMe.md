As part of this pipeline we have discussed the folowing:
1. Secure Files
2. Variables Groups
3. Variable Groups integrated with Azure Keyvault.
4. YAML Conditions.
5. Using Packer, Terraform, Docker & Ansible with in the pipeline.
6. Running Agent as systemd service. After the agent is installed on the Azure Ubuntu 20.04
   run following commands and agent runs in backgroud even after reboot.
   sudo ./svc.sh install adminsree
   sudo ./svc.sh start

Following Files need to be created as secure files:
access.auto.tfvars
aws_access_key = "ABCDEF"
aws_secret_key = "ABCDEF123456"

backend.json
{
    "access_key": "ABCDEF",
    "secret_key": "ABCDEF123456"
}

packer-vars.json
{
    "aws_access_key": "ABCDEF",
    "aws_secret_key": "ABCDEF123456",
    "region": "us-east-1",
    "source_ami": "ami-08d4ac5b634553e16",
    "instance_type": "t2.micro",
    "vpc_id": "vpc-xxxx",
    "subnet_id": "subnet-xxxxx"
}

LaptopKey.pem
-----BEGIN RSA PRIVATE KEY-----
...
-----END RSA PRIVATE KEY-----
