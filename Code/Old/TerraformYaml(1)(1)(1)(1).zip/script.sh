#!/bin/bash
for I in {1..2}
do
echo "The Value of I is $I"
echo $(date)
sleep 1
done